﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.IO;

namespace nevjegyek
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        Nevjegykezelo nevjegykezelo = new Nevjegykezelo();
        public MainWindow()
        {
            InitializeComponent();
            LVszemelyek.ItemsSource = nevjegykezelo.GetSzemelyek();
            BtorlesNevjegy.Click += NevjegyTorlesClicked;
            BujNevjegy.Click += NevUjnevjegyClicked;
         

        }

        private void mentes(object sender, RoutedEventArgs e)
        {
            Microsoft.Win32.SaveFileDialog dlg = new Microsoft.Win32.SaveFileDialog();
            dlg.DefaultExt = ".txt";
            dlg.Filter = "Text documents (.txt)|*.txt";
            if (dlg.ShowDialog() == true)
            {
                string filename = dlg.FileName;
                nevjegykezelo.mentes(filename);
            }
            
        }

        private void megnyitas(object sender, RoutedEventArgs e)
        {
            Microsoft.Win32.OpenFileDialog dlg = new Microsoft.Win32.OpenFileDialog();
            dlg.DefaultExt = ".txt";
            dlg.Filter = "Text documents (.txt)|*.txt";
            if (dlg.ShowDialog() == true)
            {
                string filename = dlg.FileName;
                nevjegykezelo.megnyitas(filename);
            }

            LVszemelyek.ItemsSource = null;
            LVszemelyek.ItemsSource = nevjegykezelo.GetSzemelyek();
        }
        private void NevUjnevjegyClicked(object sender, RoutedEventArgs e)
        {
            String nev = TBujnev.Text;
            String tel = TBujtelefonmszam.Text;

            try
            {
                if (nev == "" || tel == "")
                {
                    throw new Exception("Add meg az új nevet és telefonszámot is!");
                }

                Szemely ujszemely = new Szemely(nev, tel);
                nevjegykezelo.UjSzemely(ujszemely);
                LVszemelyek.ItemsSource = null;
                LVszemelyek.ItemsSource = nevjegykezelo.GetSzemelyek();


            }
            catch (Exception exp)
            {
                MessageBox.Show(exp.Message);
            }
            
        }
   
        private void NevjegyTorlesClicked(object sender, RoutedEventArgs e)
        {
            var selectedSzemely = LVszemelyek.SelectedItem;

            if (selectedSzemely != null)
            {
                nevjegykezelo.TorolSzemely((Szemely)selectedSzemely);
                LVszemelyek.ItemsSource = null;
                LVszemelyek.ItemsSource = nevjegykezelo.GetSzemelyek();
            }    
        }

}

    public class Szemely
    {
        private String nev;
        private String telefonszam;

        public String Nev {
            get{return nev;}
        }

        public String Telefonszam
        {
            get { return telefonszam; }
        }

        public Szemely(String _nev, String _tel)
        {
            this.nev = _nev;
            this.telefonszam = _tel;
        }

        public override string ToString()
        {
            return $"{nev};{telefonszam}";
        }
    }
    public class Nevjegykezelo {
        private List<Szemely> szemelyek;

        public Nevjegykezelo()
        {
            szemelyek = new List<Szemely>();
        }

        public void UjSzemely(Szemely szemely)
        {
            szemelyek.Add(szemely);
        }

        public void TorolSzemely(Szemely szemely)
        {
            szemelyek.Remove(szemely);
        }

        public List<Szemely> GetSzemelyek()
        {
            return szemelyek;
        }

        public void mentes(string fileName)
        {

            using (StreamWriter sw = new StreamWriter(fileName))
            {
                foreach (var szemely in szemelyek)
                {
                    sw.WriteLine(szemely);
                }
            }

        }

        public void megnyitas(String fileName)
        {

            using (StreamReader sr = new StreamReader(fileName))
            {

                szemelyek.Clear();
                string line = sr.ReadLine();

                while (line != null)
                {
                    String[] data = line.Split(";");
                    var szemely = new Szemely(data[0], data[1]);
                    this.UjSzemely(szemely);
                    line = sr.ReadLine();
                }


            }

        }

    
    }

}
